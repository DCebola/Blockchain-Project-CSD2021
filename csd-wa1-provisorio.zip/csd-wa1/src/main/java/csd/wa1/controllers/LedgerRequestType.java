package csd.wa1.controllers;

public enum LedgerRequestType {
    OBTAIN_COINS, TRANSFER_MONEY, CURRENT_AMOUNT, GLOBAL_LEDGER, CLIENT_LEDGER
}
