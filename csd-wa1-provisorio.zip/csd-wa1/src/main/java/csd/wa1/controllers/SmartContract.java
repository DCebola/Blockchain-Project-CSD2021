package csd.wa1.controllers;

public class SmartContract {
}
