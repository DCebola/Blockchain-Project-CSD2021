package csd.wa1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsdWa1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
